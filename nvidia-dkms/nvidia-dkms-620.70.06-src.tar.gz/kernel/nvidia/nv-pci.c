/*
 * SPDX-FileCopyrightText: Copyright (c) 2019-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: MIT
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "nv-pci-table.h"
#include "nv-pci-types.h"
#include "nv-pci.h"
#include "nv-msi.h"
#include "nv-hypervisor.h"
#include "nv-reg.h"
#include "nv-tegra-clk.h"
#include "nvstatuscodes.h"

#define NV_TDISP_AER_DVSEC0_OFFSET          0x0af8U
#define NV_TDISP_AER_TDI_STATE_SHIFT        30U
#define NV_TDISP_AER_TDI_STATE_MASK         0x3U
#define NV_TDISP_AER_TDI_STATE_ERROR        0x3U
#define NV_TDISP_AER_XID                    79U
#define NV_TDISP_AER_TDI_STATE(_dvsec0)                                \
    (((_dvsec0) >> NV_TDISP_AER_TDI_STATE_SHIFT) &                    \
     NV_TDISP_AER_TDI_STATE_MASK)

#if defined(NV_VGPU_KVM_BUILD)
#include "nv-vgpu-vfio-interface.h"
#endif
#include <linux/completion.h>
#include <linux/iommu.h>
#include <linux/kthread.h>

#if defined(NV_SEQ_READ_ITER_PRESENT)
#include <linux/seq_file.h>
#include <linux/kernfs.h>
#endif

#include "detect-self-hosted.h"

#if !defined(NV_BUS_TYPE_HAS_IOMMU_OPS)
#include <linux/iommu.h>
#endif
#if NV_IS_EXPORT_SYMBOL_GPL_pci_ats_supported
#include <linux/pci-ats.h>
#endif

extern int NVreg_ExcludeAllGpus;

static void
nv_check_and_exclude_gpu(
    nvidia_stack_t *sp,
    nv_state_t *nv
)
{
    char *uuid_str;

    if (NVreg_ExcludeAllGpus)
    {
        NV_DEV_PRINTF(NV_DBG_INFO, nv, "Excluding all GPUs as requested\n");
        nv->flags |= NV_FLAG_EXCLUDE;
        return;
    }

    uuid_str = rm_get_gpu_uuid(sp, nv);
    if (uuid_str == NULL)
    {
        NV_DEV_PRINTF(NV_DBG_INFO, nv, "Unable to read UUID");
        return;
    }

    if (nv_is_uuid_in_gpu_exclusion_list(uuid_str))
    {
        NV_STATUS rm_status = rm_exclude_adapter(sp, nv);
        if (rm_status != NV_OK)
        {
            NV_DEV_PRINTF_STATUS(NV_DBG_ERRORS, nv, rm_status,
                          "Failed to exclude GPU %s", uuid_str);
            goto done;
        }
        nv->flags |= NV_FLAG_EXCLUDE;
        NV_DEV_PRINTF(NV_DBG_INFO, nv, "Excluded GPU %s successfully\n",
                      uuid_str);
    }

done:
    os_free_mem(uuid_str);
}

static NvBool nv_treat_missing_irq_as_error(void)
{
#if defined(NV_LINUX_PCIE_MSI_SUPPORTED)
    return (nv_get_hypervisor_type() != OS_HYPERVISOR_HYPERV);
#else
    return NV_TRUE;
#endif
}

static void nv_get_pci_sysfs_config
(
    struct pci_dev *pci_dev,
    nv_linux_state_t *nvl
)
{
#if NV_FILESYSTEM_ACCESS_AVAILABLE
    char filename[50];
    int ret;

    ret = snprintf(filename, sizeof(filename),
                   "/sys/bus/pci/devices/%04x:%02x:%02x.0/config",
                   NV_PCI_DOMAIN_NUMBER(pci_dev),
                   NV_PCI_BUS_NUMBER(pci_dev),
                   NV_PCI_SLOT_NUMBER(pci_dev));
    if (ret > 0 && ret < sizeof(filename))
    {
        struct file *file = filp_open(filename, O_RDONLY, 0);
        if (!IS_ERR(file))
        {
#if defined(NV_SEQ_READ_ITER_PRESENT)
            /*
             * Sanity check for confirming if file path is mounted over
             * sysfs file system.
             */
            if ((file->f_inode != NULL) && (file->f_inode->i_sb != NULL) &&
                (strcmp(file->f_inode->i_sb->s_id, "sysfs") == 0))
            {
                struct seq_file *sf = file->private_data;

                /*
                 * Sanity check for confirming if 'file->private_data'
                 * actually points to 'struct seq_file'.
                 */
                if ((sf != NULL) && (sf->file == file) && (sf->op == NULL))
                {
                    struct kernfs_open_file *of = sf->private;

                    /*
                     * Sanity check for confirming if 'sf->private'
                     * actually points to 'struct kernfs_open_file'.
                     */
                    if ((of != NULL) && (of->file == file) &&
                        (of->seq_file == sf))
                    {
                        nvl->sysfs_config_file = file;
                    }
                }
            }

            if (nvl->sysfs_config_file == NULL)
            {
                filp_close(file, NULL);
            }
#else
            nvl->sysfs_config_file = file;
#endif
        }
    }
#endif
}

static int nv_resize_pcie_bars(struct pci_dev *pci_dev) {
    nv_printf(NV_DBG_INFO, "NVRM: Resizable BAR is not supported on this driver version.\n");
    return 0;
}

void
nv_init_gpu_numa_info
(
    nv_state_t *nv
)
{
    return;
}

void
nv_init_coherent_gpu_info
(
    nv_state_t *nv
)
{
    return;
}


static void nv_init_dynamic_power_management
(
    nvidia_stack_t *sp,
    struct pci_dev *pci_dev
)
{
    nv_linux_state_t *nvl = pci_get_drvdata(pci_dev);
    nv_state_t *nv = NV_STATE_PTR(nvl);
    NvBool pr3_acpi_method_present = NV_FALSE;

    nvl->sysfs_config_file = NULL;

    nv_get_pci_sysfs_config(pci_dev, nvl);

    if (nv_get_hypervisor_type() != OS_HYPERVISOR_UNKNOWN)
    {
        pr3_acpi_method_present = nv_acpi_power_resource_method_present(pci_dev);
    }
    else if (pci_dev->bus && pci_dev->bus->self)
    {
        pr3_acpi_method_present = nv_acpi_power_resource_method_present(pci_dev->bus->self);
    }

    rm_init_dynamic_power_management(sp, nv, pr3_acpi_method_present);
}

static void nv_init_tegra_gpu_pg_mask(nvidia_stack_t *sp, struct pci_dev *pci_dev)
{
}

static NvBool
nv_pci_validate_bars(const struct pci_dev *pci_dev, NvBool only_bar0)
{
    unsigned int i, j;
    NvBool last_bar_64bit = NV_FALSE;

    for (i = 0, j = 0; i < NVRM_PCICFG_NUM_BARS && j < NV_GPU_NUM_BARS; i++)
    {
        if (NV_PCI_RESOURCE_VALID(pci_dev, i))
        {
            if ((NV_PCI_RESOURCE_FLAGS(pci_dev, i) & PCI_BASE_ADDRESS_MEM_TYPE_64) &&
                (NV_PCI_RESOURCE_FLAGS(pci_dev, i) & PCI_BASE_ADDRESS_MEM_PREFETCH))
            {
                last_bar_64bit = NV_TRUE;
            }

            //
            // If we are here, then we have found a valid BAR -- 32 or 64-bit.
            //
            j++;

            if (only_bar0)
                return NV_TRUE;

            continue;
        }

        //
        // If last_bar_64bit is "true" then, we are looking at the 2nd (upper)
        // half of the 64-bit BAR. This is typically all 0s which looks invalid
        // but it's normal and not a problem and we can ignore it and continue.
        //
        if (last_bar_64bit)
        {
            last_bar_64bit = NV_FALSE;
            continue;
        }

        // Invalid 32 or 64-bit BAR.
        nv_printf(NV_DBG_ERRORS,
            "NVRM: This PCI I/O region assigned to your NVIDIA device is invalid:\n"
            "NVRM: BAR%d is %" NvU64_fmtu "M @ 0x%" NvU64_fmtx " (PCI:%04x:%02x:%02x.%x)\n", i,
            (NvU64)(NV_PCI_RESOURCE_SIZE(pci_dev, i) >> 20),
            (NvU64)NV_PCI_RESOURCE_START(pci_dev, i),
            NV_PCI_DOMAIN_NUMBER(pci_dev), NV_PCI_BUS_NUMBER(pci_dev),
            NV_PCI_SLOT_NUMBER(pci_dev), PCI_FUNC(pci_dev->devfn));

        return NV_FALSE;
    }

    return NV_TRUE;
}

typedef struct
{
    struct pci_dev *pci_dev;
    const struct pci_device_id *id_table;
    struct completion done;
    int rc;
} nv_pci_probe_deferred_context_t;

/* Used to differentiate probe behavior during driver registration vs later rebinds */
static NvBool nv_pci_driver_registration_in_progress = NV_FALSE;

static NvBool
nv_tdisp_probe_dma_mapping_readiness
(
    nv_linux_state_t *nvl
)
{
    nv_state_t *nv = NV_STATE_PTR(nvl);

#if defined(NV_DMA_ATTR_REQUIRE_COHERENT_PRESENT)
    {
        struct page *page;
        dma_addr_t dma_addr;

        page = alloc_page(GFP_KERNEL | GFP_DMA32 | __GFP_ZERO);
        if (page == NULL)
        {
            NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                          "TDISP-DMA-READINESS: page allocation failed, dma_ready=0\n");
            return NV_FALSE;
        }

        dma_addr = dma_map_page_attrs(nvl->dev, page, 0, PAGE_SIZE,
                                      DMA_BIDIRECTIONAL,
                                      DMA_ATTR_REQUIRE_COHERENT);
        if (dma_mapping_error(nvl->dev, dma_addr))
        {
            __free_page(page);
            NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                          "TDISP-DMA-READINESS: protected mapping failed, dma_ready=0\n");
            return NV_FALSE;
        }

        dma_unmap_page_attrs(nvl->dev, dma_addr, PAGE_SIZE,
                             DMA_BIDIRECTIONAL,
                             DMA_ATTR_REQUIRE_COHERENT);
        __free_page(page);

        NV_DEV_PRINTF(NV_DBG_INFO, nv,
                      "TDISP-DMA-READINESS: protected mapping ready, dma_ready=1\n");
        return NV_TRUE;
    }
#else
    NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                  "TDISP-DMA-READINESS: DMA_ATTR_REQUIRE_COHERENT unavailable, dma_ready=0\n");
    return NV_FALSE;
#endif
}

/* find nvidia devices and set initial state */
static int
nv_pci_probe_body
(
    struct pci_dev *pci_dev,
    const struct pci_device_id *id_table
)
{
    nv_state_t *nv = NULL;
    nv_linux_state_t *nvl = NULL;
    unsigned int i, j;
    int flags = 0;
    nvidia_stack_t *sp = NULL;
    NV_STATUS status;
    NvU8 regs_bar_index = nv_bar_index_to_os_bar_index(pci_dev,
                                                       NV_GPU_BAR_INDEX_REGS);
    NvBool bar0_requested = NV_FALSE;

    nv_printf(NV_DBG_SETUP, "NVRM: probing 0x%x 0x%x, class 0x%x\n",
        pci_dev->vendor, pci_dev->device, pci_dev->class);

#ifdef NV_PCI_SRIOV_SUPPORT
    if (pci_dev->is_virtfn)
    {
#if defined(NV_VGPU_KVM_BUILD)
#if defined(NV_BUS_TYPE_HAS_IOMMU_OPS)
        if (pci_dev->dev.bus->iommu_ops == NULL) 
#else
        if ((pci_dev->dev.iommu != NULL) && (pci_dev->dev.iommu->iommu_dev != NULL) &&
            (pci_dev->dev.iommu->iommu_dev->ops == NULL))
#endif
        {
            nv_printf(NV_DBG_ERRORS, "NVRM: Aborting probe for VF %04x:%02x:%02x.%x "
                      "since IOMMU is not present on the system.\n",
                       NV_PCI_DOMAIN_NUMBER(pci_dev), NV_PCI_BUS_NUMBER(pci_dev),
                       NV_PCI_SLOT_NUMBER(pci_dev), PCI_FUNC(pci_dev->devfn));
            return -1;
        }

        return 0;
#else
        nv_printf(NV_DBG_ERRORS, "NVRM: Ignoring probe for VF %04x:%02x:%02x.%x ",
                  NV_PCI_DOMAIN_NUMBER(pci_dev), NV_PCI_BUS_NUMBER(pci_dev),
                  NV_PCI_SLOT_NUMBER(pci_dev), PCI_FUNC(pci_dev->devfn));

        return -1;
#endif /* NV_VGPU_KVM_BUILD */
    }
#endif /* NV_PCI_SRIOV_SUPPORT */

    if (nv_kmem_cache_alloc_stack(&sp) != 0)
    {
        return -1;
    }

    if (!rm_wait_for_bar_firewall(
                sp,
                NV_PCI_DOMAIN_NUMBER(pci_dev),
                NV_PCI_BUS_NUMBER(pci_dev),
                NV_PCI_SLOT_NUMBER(pci_dev),
                PCI_FUNC(pci_dev->devfn),
                pci_dev->device,
                pci_dev->subsystem_device))
    {
        nv_printf(NV_DBG_ERRORS,
            "NVRM: failed to wait for bar firewall to lower\n");
        goto failed;
    }

    if (!rm_is_supported_pci_device(
                (pci_dev->class >> 16) & 0xFF,
                (pci_dev->class >> 8) & 0xFF,
                pci_dev->vendor,
                pci_dev->device,
                pci_dev->subsystem_vendor,
                pci_dev->subsystem_device,
                NV_FALSE /* print_legacy_warning */))
    {
        nv_printf(NV_DBG_ERRORS, "NVRM: ignoring the legacy GPU %04x:%02x:%02x.%x\n",
                  NV_PCI_DOMAIN_NUMBER(pci_dev), NV_PCI_BUS_NUMBER(pci_dev),
                  NV_PCI_SLOT_NUMBER(pci_dev), PCI_FUNC(pci_dev->devfn));
        goto failed;
    }

    atomic_inc(&num_probed_nv_devices);

    if (pci_enable_device(pci_dev) != 0)
    {
        nv_printf(NV_DBG_ERRORS,
            "NVRM: pci_enable_device failed, aborting\n");
        goto failed;
    }

    if ((pci_dev->irq == 0 && !pci_find_capability(pci_dev, PCI_CAP_ID_MSIX))
        && nv_treat_missing_irq_as_error())
    {
        nv_printf(NV_DBG_ERRORS, "NVRM: Can't find an IRQ for your NVIDIA card!\n");
        nv_printf(NV_DBG_ERRORS, "NVRM: Please check your BIOS settings.\n");
        nv_printf(NV_DBG_ERRORS, "NVRM: [Plug & Play OS] should be set to NO\n");
        nv_printf(NV_DBG_ERRORS, "NVRM: [Assign IRQ to VGA] should be set to YES \n");
        goto failed;
    }

    // Validate if BAR0 is usable
    if (!nv_pci_validate_bars(pci_dev, /* only_bar0 = */ NV_TRUE))
        goto failed;

    /*
     * CXL GPUs: do NOT claim BAR0 here.  The CXL component registers live
     * within BAR0, and cxl_port needs to devm_request_mem_region a sub-range
     * of it.  Linux's resource tree treats a request_mem_region claim as BUSY
     * (IORESOURCE_BUSY), which prevents any child allocation inside it.
     * When the nvidia driver registers (pci_register_driver), the kernel
     * retries deferred CXL endpoint probes; if BAR0 is already BUSY at that
     * moment, cxl_port fails and cxlmd->endpoint is never set, so
     * cxl_get_committed_decoder() returns NULL.
     *
     * For CXL GPUs we skip the claim entirely.  nv_pci_remove() is guarded
     * symmetrically so that release_mem_region(BAR0) is also skipped.
     * Non-CXL GPUs retain the existing claim/release behaviour.
     */

    {
        if (!request_mem_region(NV_PCI_RESOURCE_START(pci_dev, regs_bar_index),
                                NV_PCI_RESOURCE_SIZE(pci_dev, regs_bar_index),
                                nv_device_name))
        {
            nv_printf(NV_DBG_ERRORS,
                "NVRM: request_mem_region failed for %" NvU64_fmtu "M @ 0x%" NvU64_fmtx ". This can\n"
                "NVRM: occur when a driver such as rivatv is loaded and claims\n"
                "NVRM: ownership of the device's registers.\n",
                (NvU64)(NV_PCI_RESOURCE_SIZE(pci_dev, regs_bar_index) >> 20),
                (NvU64)NV_PCI_RESOURCE_START(pci_dev, regs_bar_index));
            goto failed;
        }
        bar0_requested = NV_TRUE;
    }

    NV_KZALLOC(nvl, sizeof(nv_linux_state_t));
    if (nvl == NULL)
    {
        nv_printf(NV_DBG_ERRORS, "NVRM: failed to allocate memory\n");
        goto err_not_supported;
    }

    nv  = NV_STATE_PTR(nvl);
    atomic_set(&nvl->tdisp_aer_reported, 0);
    os_mem_copy(nv->cached_gpu_info.vbios_version, "??.??.??.??.??", 15);

    for (i = 0; i < NVRM_PCICFG_NUM_BARS; i++)
    {
        if ((NV_PCI_RESOURCE_VALID(pci_dev, i)) &&
            (NV_PCI_RESOURCE_FLAGS(pci_dev, i) & PCI_BASE_ADDRESS_SPACE)
                == PCI_BASE_ADDRESS_SPACE_MEMORY)
        {
            nv->bars[NV_GPU_BAR_INDEX_REGS].offset = NVRM_PCICFG_BAR_OFFSET(i);
            nv->bars[NV_GPU_BAR_INDEX_REGS].cpu_address = NV_PCI_RESOURCE_START(pci_dev, i);
            nv->bars[NV_GPU_BAR_INDEX_REGS].size = NV_PCI_RESOURCE_SIZE(pci_dev, i);

            break;
        }
    }
    nv->regs = &nv->bars[NV_GPU_BAR_INDEX_REGS];

    pci_set_drvdata(pci_dev, (void *)nvl);

    /* default to 32-bit PCI bus address space */
    pci_dev->dma_mask = 0xffffffffULL;

    dma_set_max_seg_size(&pci_dev->dev, U32_MAX);

    nvl->dev               = &pci_dev->dev;
    nvl->pci_dev           = pci_dev;
    nvl->dma_dev.dev       = nvl->dev;

    nv->pci_info.vendor_id = pci_dev->vendor;
    nv->pci_info.device_id = pci_dev->device;
    nv->subsystem_id       = pci_dev->subsystem_device;
    nv->subsystem_vendor   = pci_dev->subsystem_vendor;
    nv->os_state           = (void *) nvl;
    nv->dma_dev            = &nvl->dma_dev;
    nv->pci_info.domain    = NV_PCI_DOMAIN_NUMBER(pci_dev);
    nv->pci_info.bus       = NV_PCI_BUS_NUMBER(pci_dev);
    nv->pci_info.slot      = NV_PCI_SLOT_NUMBER(pci_dev);
    nv->pci_info.function  = PCI_FUNC(pci_dev->devfn);
    nv->handle             = pci_dev;
    nv->flags             |= flags;

    if (!nv_lock_init_locks(sp, nv))
    {
        goto err_not_supported;
    }

    if ((rm_is_supported_device(sp, nv)) != NV_OK)
        goto err_not_supported;

    // Wire RM HAL
    if (!rm_init_private_state(sp, nv))
    {
        NV_DEV_PRINTF(NV_DBG_ERRORS, nv, "rm_init_private_state() failed!\n");
        goto err_zero_dev;
    }

    if (!nv->is_tegra_pci_igpu &&
        !pci_devid_is_self_hosted(pci_dev->device) &&
        !nv_pci_validate_bars(pci_dev, /* only_bar0 = */ NV_FALSE))
        goto err_zero_dev;

    if (nv_resize_pcie_bars(pci_dev)) {
        nv_printf(NV_DBG_ERRORS,
            "NVRM: Fatal Error while attempting to resize PCIe BARs.\n");
        goto err_zero_dev;
    }

    nvl->all_mappings_revoked = NV_TRUE;
    nvl->safe_to_mmap = NV_TRUE;
    nvl->gpu_wakeup_callback_needed = NV_TRUE;
    INIT_LIST_HEAD(&nvl->open_files);

    if (!nv->is_tegra_pci_igpu)
    {
        for (i = 0, j = 0; i < NVRM_PCICFG_NUM_BARS && j < NV_GPU_NUM_BARS; i++)
        {
            if (j == NV_GPU_BAR_INDEX_REGS)
            {
                j++;
                continue;
            }

            if ((NV_PCI_RESOURCE_VALID(pci_dev, i)) &&
                (NV_PCI_RESOURCE_FLAGS(pci_dev, i) & PCI_BASE_ADDRESS_SPACE)
                    == PCI_BASE_ADDRESS_SPACE_MEMORY)
            {
                nv->bars[j].offset = NVRM_PCICFG_BAR_OFFSET(i);
                nv->bars[j].cpu_address = NV_PCI_RESOURCE_START(pci_dev, i);
                nv->bars[j].size = NV_PCI_RESOURCE_SIZE(pci_dev, i);
                j++;
            }
        }
    }

    nv->fb   = &nv->bars[NV_GPU_BAR_INDEX_FB];
    nv->interrupt_line = pci_dev->irq;

    NV_ATOMIC_SET(nvl->numa_info.status, NV_IOCTL_NUMA_STATUS_DISABLED);
    nvl->numa_info.node_id = NUMA_NO_NODE;

    nv_clk_get_handles(nv);

    pci_set_master(pci_dev);

    if (os_tdisp_enabled)
    {
        nv->tdisp_dma_mapping_ready =
            nv_tdisp_probe_dma_mapping_readiness(nvl);
    }

    /*
     * Snapshot config for AER/DPC recovery. A fatal link-down reset leaves the
     * function at post-reset defaults; unlike a reboot, firmware/PCI bring-up
     * does not reprogram BAR registers and related config, so nv_pci_slot_reset
     * must restore a known-good image. Save here (after pci_set_master) so the
     * image matches post-probe config, not an earlier enum-time save. Skip when
     * the feature is disabled so a save failure does not produce a recovery-
     * related error log for opted-out systems.
     */
    if (NVreg_EnablePCIeErrorRecovery != 0)
    {
        if (pci_save_state(pci_dev) != 0)
        {
            NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                          "Failed to save PCI config state. PCIe error recovery will not be able to restore it\n");
        }
    }

    nv->primary_vga = ((NV_PCI_RESOURCE_FLAGS(pci_dev, PCI_ROM_RESOURCE) &
                        IORESOURCE_ROM_SHADOW) == IORESOURCE_ROM_SHADOW);

#if defined(CONFIG_VGA_ARB)
#if defined(VGA_DEFAULT_DEVICE)
#if defined(NV_VGA_TRYGET_PRESENT)
    vga_tryget(VGA_DEFAULT_DEVICE, VGA_RSRC_LEGACY_MASK);
#endif
#endif
    vga_set_legacy_decoding(pci_dev, VGA_RSRC_NONE);
#endif

    status = nv_check_gpu_state(nv);
    if (status == NV_ERR_GPU_IS_LOST)
    {
        NV_DEV_PRINTF(NV_DBG_INFO, nv, "GPU is lost, skipping nv_pci_probe\n");
        goto err_gpu_lost;
    }

    nv->cpu_numa_node_id = dev_to_node(nvl->dev);

    if (nv_platform_use_auto_online(nvl))
    {
        nv_init_gpu_numa_info(nv);
    }

    /* Resolve per-device init_on_probe from NVreg_GpuInitOnProbe policy. */
    nv_set_init_on_probe(nv);

    if (nv_linux_init_open_q(nvl) != 0)
    {
        NV_DEV_PRINTF(NV_DBG_ERRORS, nv, "nv_linux_init_open_q() failed!\n");
        goto err_gpu_lost;
    }

    nv_printf(NV_DBG_INFO,
              "NVRM: PCI:%04x:%02x:%02x.%x (%04x:%04x): BAR0 @ 0x%llx (%lluMB)\n",
              nv->pci_info.domain, nv->pci_info.bus, nv->pci_info.slot,
              PCI_FUNC(pci_dev->devfn), nv->pci_info.vendor_id, nv->pci_info.device_id,
              nv->regs->cpu_address, (nv->regs->size >> 20));
    nv_printf(NV_DBG_INFO,
              "NVRM: PCI:%04x:%02x:%02x.%x (%04x:%04x): BAR1 @ 0x%llx (%lluMB)\n",
              nv->pci_info.domain, nv->pci_info.bus, nv->pci_info.slot,
              PCI_FUNC(pci_dev->devfn), nv->pci_info.vendor_id, nv->pci_info.device_id,
              nv->fb->cpu_address, (nv->fb->size >> 20));

    atomic_inc(&num_nv_devices);

    pm_vt_switch_required(nvl->dev, NV_TRUE);

    nv_init_dynamic_power_management(sp, pci_dev);

    nv_init_tegra_gpu_pg_mask(sp, pci_dev);

    rm_get_gpu_uuid_raw(sp, nv);

    /* Parse and set any per-GPU dword registry keys specified. */
    nv_parse_per_device_option_string(sp, nv);

    /* Parse and set per-device binary registry key files. */
    {
        NV_STATUS parse_status = nv_parse_per_device_binary_option_string(sp, nv);
        if (parse_status != NV_OK)
        {
            NV_DEV_PRINTF(NV_DBG_WARNINGS, nv,
                          "Per-device binary registry key parsing failed during probe (status=0x%x)\n",
                          parse_status);
        }
    }

    rm_set_rm_firmware_requested(sp, nv);

    nv_check_and_exclude_gpu(sp, nv);

#if defined(DPM_FLAG_NO_DIRECT_COMPLETE)
    dev_pm_set_driver_flags(nvl->dev, DPM_FLAG_NO_DIRECT_COMPLETE);
#elif defined(DPM_FLAG_NEVER_SKIP)
    dev_pm_set_driver_flags(nvl->dev, DPM_FLAG_NEVER_SKIP);
#endif

    /*
     * Assign a minor number for the newly created nvl object
     */
    LOCK_NV_LINUX_DEVICES();
    if (nv_linux_assign_minor_locked(nvl) != 0)
    {
        UNLOCK_NV_LINUX_DEVICES();
        goto err_add_device;
    }
    UNLOCK_NV_LINUX_DEVICES();

    if (nvl->init_on_probe && !(nv->flags & NV_FLAG_EXCLUDE))
    {
        int ret;
        nv_printf(NV_DBG_SETUP, "NVRM: Starting device %04x:%02x:%02x.%x\n",
            NV_PCI_DOMAIN_NUMBER(pci_dev), NV_PCI_BUS_NUMBER(pci_dev),
            NV_PCI_SLOT_NUMBER(pci_dev), PCI_FUNC(pci_dev->devfn));

        ret = nv_start_device(nv, sp);
        if (ret)
        {
            /*
             * Log the failure but do not abort probe. The device will
             * remain registered so that it can still be managed even
             * though RM init did not succeed.
             */
            nv_printf(NV_DBG_ERRORS,
                "NVRM: GPU %04x:%02x:%02x.%x init failed during probe (ret=%d).\n",
                NV_PCI_DOMAIN_NUMBER(pci_dev), NV_PCI_BUS_NUMBER(pci_dev),
                NV_PCI_SLOT_NUMBER(pci_dev), PCI_FUNC(pci_dev->devfn), ret);
        }
    }

    /*
     * The newly created nvl object is added to the nv_linux_devices global list
     * only after all the initialization operations for that nvl object are
     * completed, so as to protect against simultaneous lookup operations which
     * may discover a partially initialized nvl object in the list
     */
    LOCK_NV_LINUX_DEVICES();
    nv_linux_add_device_locked(nvl);
    UNLOCK_NV_LINUX_DEVICES();

    /*
     * Create the procfs entry only after all the initialization operations for
     * the nvl object are completed and the device is added to the
     * nv_linux_devices global list
     */
    nv_procfs_add_gpu(nvl);

#if defined(NV_VGPU_KVM_BUILD)
    /*
     * vGPU VFIO probe requires the device to be added to the nv_linux_devices
     * global list since the vgpu mgr daemon invokes a open() call on the device
     * as part of the probe sequence
     */
    if (nvidia_vgpu_vfio_probe(nvl->pci_dev) != NV_OK)
    {
        NV_DEV_PRINTF(NV_DBG_ERRORS, nv, "Failed to register device to vGPU VFIO module");
        goto err_free_all;
    }
#endif

    /*
     * Notification must be sent only after all the initialization operations
     * as part of the probe sequence are complete.
     * Do not add code after this line which can fail nv_pci_probe().
     */
    rm_notify_gpu_addition(sp, nv);

    nvidia_modeset_probe(nvl);

    /*
     * Dynamic power management should be enabled as the last step.
     * Kernel runtime power management framework can put the device
     * into the suspended state. Hardware register access should not be done
     * after enabling dynamic power management.
     */
    rm_enable_dynamic_power_management(sp, nv);

    if (nv->ats_support)
        WRITE_ONCE(nv_ats_supported, NV_TRUE);
    else
        WRITE_ONCE(nv_non_ats_device_present, NV_TRUE);

    nv_kmem_cache_free_stack(sp);

    return 0;

#if defined(NV_VGPU_KVM_BUILD)
err_free_all:
#endif
    nv_procfs_remove_gpu(nvl);
    LOCK_NV_LINUX_DEVICES();
    nv_linux_remove_device_locked(nvl);
    UNLOCK_NV_LINUX_DEVICES();
    nv_stop_device(nv, sp);
#if defined(NV_VGPU_KVM_BUILD)
err_remove_minor:
#endif
    LOCK_NV_LINUX_DEVICES();
    nv_linux_remove_minor_locked(nvl);
    UNLOCK_NV_LINUX_DEVICES();
err_add_device:
    rm_cleanup_dynamic_power_management(sp, nv);
    pm_vt_switch_unregister(nvl->dev);
    nv_linux_stop_open_q(nvl);
err_gpu_lost:
    nv_clk_clear_handles(nv);
err_zero_dev:
    rm_free_private_state(sp, nv);
err_not_supported:
    nv_lock_destroy_locks(sp, nv);
failed:
    if (bar0_requested)
    {
        release_mem_region(NV_PCI_RESOURCE_START(pci_dev, regs_bar_index),
                           NV_PCI_RESOURCE_SIZE(pci_dev, regs_bar_index));
    }
    NV_PCI_DISABLE_DEVICE(pci_dev);
    pci_set_drvdata(pci_dev, NULL);
    if (nvl != NULL)
    {
        NV_KFREE(nvl, sizeof(nv_linux_state_t));
    }
    nv_kmem_cache_free_stack(sp);
    return -1;
}

static int
nv_pci_probe_deferred_worker(void *data)
{
    nv_pci_probe_deferred_context_t *probe_ctx = data;

    probe_ctx->rc = nv_pci_probe_body(probe_ctx->pci_dev,
                                      probe_ctx->id_table);
    complete(&probe_ctx->done);

    return 0;
}

static int
nv_pci_probe
(
    struct pci_dev *pci_dev,
    const struct pci_device_id *id_table
)
{
    int rc;
    nv_pci_probe_deferred_context_t *probe_ctx = NULL;
    struct task_struct *thread = NULL;

    /*
     * Kthread deferral only helps during module-init when multiple probes
     * run concurrently via the async worker pool. Later bind/unbind from
     * sysfs or hotplug is synchronous, so the kthread overhead is not
     * worthwhile.
     */
    if (!smp_load_acquire(&nv_pci_driver_registration_in_progress))
    {
        return nv_pci_probe_body(pci_dev, id_table);
    }

    NV_KZALLOC(probe_ctx, sizeof(*probe_ctx));
    if (probe_ctx == NULL)
    {
        nv_printf(NV_DBG_ERRORS, "NVRM: failed to allocate probe deferral context for %s, falling back to inline probe\n", dev_name(&pci_dev->dev));
        return nv_pci_probe_body(pci_dev, id_table);
    }

    probe_ctx->pci_dev = pci_dev;
    probe_ctx->id_table = id_table;
    init_completion(&probe_ctx->done);

    /*
     * The kthread deferral path is shared between GPL (open) and non-GPL
     * (closed) builds to keep a single code path. On non-GPL builds,
     * PROBE_PREFER_ASYNCHRONOUS is not used because wait_for_device_probe()
     * is GPL-only, so PCI core serializes probes and the kthreads do not
     * provide parallelism. The overhead of creating and joining one kthread
     * per device is negligible.
     */
    /*
     * PROBE_PREFER_ASYNCHRONOUS only moves probe() onto the PCI core's async
     * worker pool, which is shared with other unbound kernel workqueues.
     * Under contention, running full nv_pci_probe_body() in that shared pool
     * hurts parallel initialization throughput.
     *
     * During module-init deferral window only, offload probe body to a
     * dedicated per-GPU kthread. We still join below so this probe callback
     * does not return before its own probe body finishes.
     */
    thread = kthread_run(nv_pci_probe_deferred_worker,
                         probe_ctx,
                         "nv-probe-%s",
                         dev_name(&pci_dev->dev));
    if (IS_ERR(thread))
    {
        nv_printf(NV_DBG_ERRORS, "NVRM: failed to create probe deferral kthread for %s, falling back to inline probe\n", dev_name(&pci_dev->dev));
        NV_KFREE(probe_ctx, sizeof(*probe_ctx));
        return nv_pci_probe_body(pci_dev, id_table);
    }

    wait_for_completion(&probe_ctx->done);
    rc = probe_ctx->rc;

    NV_KFREE(probe_ctx, sizeof(*probe_ctx));
    return rc;
}

static void nv_pci_remove_helper(struct pci_dev *pci_dev, bool block_if_gpu_in_use)
{
    nv_linux_state_t *nvl = NULL;
    nv_state_t *nv;
    nvidia_stack_t *sp = NULL;
    NvU8 regs_bar_index = nv_bar_index_to_os_bar_index(pci_dev,
                                                       NV_GPU_BAR_INDEX_REGS);


#ifdef NV_PCI_SRIOV_SUPPORT
    if (pci_dev->is_virtfn)
    {
#if defined(NV_VGPU_KVM_BUILD)
        /* Arg 2 == NV_TRUE means that the PCI device should be removed */
        nvidia_vgpu_vfio_remove(pci_dev, NV_TRUE);
#endif /* NV_VGPU_KVM_BUILD */
        return;
    }
#endif /* NV_PCI_SRIOV_SUPPORT */

    nvl = pci_get_drvdata(pci_dev);
    if (!nvl || (nvl->pci_dev != pci_dev))
    {
        return;
    }

    nv = NV_STATE_PTR(nvl);

    /*
     * Flush and stop open_q before proceeding with removal to ensure nvl
     * outlives all enqueued work items.
     */
    nv_linux_stop_open_q(nvl);

    nvidia_modeset_remove(nv->gpu_id);

    LOCK_NV_LINUX_DEVICES();
    down(&nvl->ldata_lock);

    if (!block_if_gpu_in_use && (atomic64_read(&nvl->usage_count) != 0))
    {
        up(&nvl->ldata_lock);
        UNLOCK_NV_LINUX_DEVICES();
        return;
    }

    if (nv_kmem_cache_alloc_stack(&sp) != 0)
    {
        up(&nvl->ldata_lock);
        UNLOCK_NV_LINUX_DEVICES();
        return;
    }

    nv_linux_remove_device_locked(nvl);

    rm_notify_gpu_removal(sp, nv);

    /*
     * Sanity check: A removed device shouldn't have a non-zero usage_count.
     * For eGPU, fall off the bus along with clients active is a valid scenario.
     * Hence skipping the sanity check for eGPU.
     */
    if ((atomic64_read(&nvl->usage_count) != 0) && !(nv->is_external_gpu))
    {
        nv_printf(NV_DBG_ERRORS,
                  "NVRM: Attempting to remove device %04x:%02x:%02x.%x with non-zero usage count!\n",
                  NV_PCI_DOMAIN_NUMBER(pci_dev), NV_PCI_BUS_NUMBER(pci_dev),
                  NV_PCI_SLOT_NUMBER(pci_dev), PCI_FUNC(pci_dev->devfn));

        /*
         * We can't return from this function without corrupting state, so we wait for
         * the usage count to go to zero.
         */
        while (atomic64_read(&nvl->usage_count) != 0)
        {
            /*
             * While waiting, release the locks so that other threads can make
             * forward progress.
             */
            up(&nvl->ldata_lock);
            UNLOCK_NV_LINUX_DEVICES();

            os_delay(500);

            /* Re-acquire the locks before checking again */
            LOCK_NV_LINUX_DEVICES();
            nvl = pci_get_drvdata(pci_dev);
            if (!nvl)
            {
                /* The device was not found, which should not happen */
                nv_printf(NV_DBG_ERRORS,
                          "NVRM: Failed removal of device %04x:%02x:%02x.%x!\n",
                          NV_PCI_DOMAIN_NUMBER(pci_dev), NV_PCI_BUS_NUMBER(pci_dev),
                          NV_PCI_SLOT_NUMBER(pci_dev), PCI_FUNC(pci_dev->devfn));
                WARN_ON(1);
                goto done;
            }
            nv = NV_STATE_PTR(nvl);
            down(&nvl->ldata_lock);
        }

        nv_printf(NV_DBG_ERRORS,
                  "NVRM: Continuing with GPU removal for device %04x:%02x:%02x.%x\n",
                  NV_PCI_DOMAIN_NUMBER(pci_dev), NV_PCI_BUS_NUMBER(pci_dev),
                  NV_PCI_SLOT_NUMBER(pci_dev), PCI_FUNC(pci_dev->devfn));
    }

    nvl->coherent_link_info.gpu_mem_info_discovery_attempted = NV_FALSE;

    rm_check_for_gpu_surprise_removal(sp, nv);

    /* Remove proc entry for this GPU */
    nv_procfs_remove_gpu(nvl);

    nv_clk_clear_handles(nv);

    nv_stop_device(nv, sp);

    rm_cleanup_dynamic_power_management(sp, nv);

    nv_linux_remove_minor_locked(nvl);
    nv->removed = NV_TRUE;

    UNLOCK_NV_LINUX_DEVICES();

    pm_vt_switch_unregister(&pci_dev->dev);

#if defined(NV_VGPU_KVM_BUILD)
    /* Arg 2 == NV_TRUE means that the PCI device should be removed */
    nvidia_vgpu_vfio_remove(pci_dev, NV_TRUE);
#endif

    if ((nv->flags & NV_FLAG_PERSISTENT_SW_STATE) || (nv->flags & NV_FLAG_INITIALIZED))
    {
        nv_acpi_unregister_notifier(nvl);
        if (nv->flags & NV_FLAG_PERSISTENT_SW_STATE)
        {
            rm_disable_gpu_state_persistence(sp, nv);
        }
        nv_shutdown_adapter(sp, nv, nvl);
        nv_dev_free_stacks(nvl);
    }

    if (nvl->sysfs_config_file != NULL)
    {
        filp_close(nvl->sysfs_config_file, NULL);
        nvl->sysfs_config_file = NULL;
    }

    if (atomic64_read(&nvl->usage_count) == 0)
    {
        nv_lock_destroy_locks(sp, nv);
    }

    atomic_dec(&num_probed_nv_devices);

    pci_set_drvdata(pci_dev, NULL);

    rm_i2c_remove_adapters(sp, nv);
    rm_free_private_state(sp, nv);

    /* BAR0 was never claimed for CXL devices; skip the matching release. */
    {
        release_mem_region(NV_PCI_RESOURCE_START(pci_dev, regs_bar_index),
                           NV_PCI_RESOURCE_SIZE(pci_dev, regs_bar_index));
    }

    atomic_dec(&num_nv_devices);

    if (atomic64_read(&nvl->usage_count) == 0)
    {
        NV_PCI_DISABLE_DEVICE(pci_dev);
        NV_KFREE(nvl, sizeof(nv_linux_state_t));
    }
    else
    {
        up(&nvl->ldata_lock);
    }

    nv_kmem_cache_free_stack(sp);
    return;

done:
    UNLOCK_NV_LINUX_DEVICES();
    nv_kmem_cache_free_stack(sp);
}

static void
nv_pci_remove(struct pci_dev *pci_dev)
{

    nv_printf(NV_DBG_SETUP, "NVRM: removing GPU %04x:%02x:%02x.%x\n",
              NV_PCI_DOMAIN_NUMBER(pci_dev), NV_PCI_BUS_NUMBER(pci_dev),
              NV_PCI_SLOT_NUMBER(pci_dev), PCI_FUNC(pci_dev->devfn));

    nv_pci_remove_helper(pci_dev, true);
}

static void
nv_pci_shutdown(struct pci_dev *pci_dev)
{
    nv_linux_state_t *nvl = pci_get_drvdata(pci_dev);
    
    if (!nvl || (nvl->pci_dev != pci_dev))
    {
        return;
    }

    if (nvl->is_forced_shutdown)
    {
        nvl->is_forced_shutdown = NV_FALSE;
        return;
    }

    nv_pci_remove_helper(pci_dev, false);

    if (pci_get_drvdata(pci_dev) != NULL)
    {
        nvl->nv_state.is_shutdown = NV_TRUE;
    }

    /* pci_clear_master is not defined for !CONFIG_PCI */
#ifdef CONFIG_PCI
    pci_clear_master(pci_dev);
#endif

    /* SHH HW mandates 1us delay to realise the effects of
     * Bus Mater Enable(BME) disable. Adding 1us delay for
     * all the chips as the delay is not in the data path
     * and not big. Creating HAL for this would be a overkill.
     */
    udelay(1);
}

int nvidia_dev_get_pci_info(const NvU8 *uuid, struct pci_dev **pci_dev_out,
    NvU64 *dma_start, NvU64 *dma_limit)
{
    nv_linux_state_t *nvl;

    /* Takes nvl->ldata_lock */
    nvl = find_uuid(uuid);
    if (!nvl)
        return -ENODEV;

    *pci_dev_out = nvl->pci_dev;
    *dma_start = nvl->dma_dev.addressable_range.start;
    *dma_limit = nvl->dma_dev.addressable_range.limit;

    up(&nvl->ldata_lock);

    return 0;
}

NvU8 nv_find_pci_capability(struct pci_dev *pci_dev, NvU8 capability)
{
    u16 status = 0;
    u8  cap_ptr = 0, cap_id = 0xff;

    pci_read_config_word(pci_dev, PCI_STATUS, &status);
    status &= PCI_STATUS_CAP_LIST;
    if (!status)
        return 0;

    switch (pci_dev->hdr_type) {
        case PCI_HEADER_TYPE_NORMAL:
        case PCI_HEADER_TYPE_BRIDGE:
            pci_read_config_byte(pci_dev, PCI_CAPABILITY_LIST, &cap_ptr);
            break;
        default:
            return 0;
    }

    do {
        cap_ptr &= 0xfc;
        pci_read_config_byte(pci_dev, cap_ptr + PCI_CAP_LIST_ID, &cap_id);
        if (cap_id == capability)
            return cap_ptr;
        pci_read_config_byte(pci_dev, cap_ptr + PCI_CAP_LIST_NEXT, &cap_ptr);
    } while (cap_ptr && cap_id != 0xff);

    return 0;
}

NV_STATUS
nv_pci_find_nvidia_dvsec_capability
(
    struct pci_dev *dev,
    NvU16 target_dvsec_id,
    NvU32 *dvsec_offset,
    NvU32 *dvsec_length
)
{
    u32 cap_offset = NV_PCI_EXT_CAP_START_OFFSET;
    u32 hdr0;
    u32 hdr1;
    u32 hdr2;
    u32 i;
    int rc;

    if ((dev == NULL) || (dvsec_offset == NULL) || (dvsec_length == NULL))
    {
        return NV_ERR_INVALID_ARGUMENT;
    }

    /*
     * Iterate over the capabilities linked list until the target DVSEC is found
     * or we reach the end of the list (offset of 0).
     */

    for (i = 0; i < NV_PCI_EXT_CAP_MAX_ITERATIONS; i++)
    {
        /*
         * The capability offset should always be within the extended capability
         * space.
         */
        if ((cap_offset < NV_PCI_EXT_CAP_START_OFFSET) ||
            (cap_offset >= NV_PCI_EXT_CAP_END_OFFSET))
        {
            nv_printf(NV_DBG_ERRORS,
                      "NVRM: Malformed PCI extended capability chain while searching for NVIDIA DVSEC%u: offset 0x%x out of range\n",
                      target_dvsec_id, cap_offset);
            return NV_ERR_INVALID_OFFSET;
        }

        /*
         * The capability offset should always be aligned to DWORD boundary.
         */
        if (!NV_IS_ALIGNED(cap_offset, sizeof(NvU32)))
        {
            nv_printf(NV_DBG_ERRORS,
                      "NVRM: Malformed PCI extended capability chain while searching for NVIDIA DVSEC%u: offset 0x%x is not DWORD aligned\n",
                      target_dvsec_id, cap_offset);
            return NV_ERR_INVALID_OFFSET;
        }

        rc = pci_read_config_dword(dev, cap_offset, &hdr0);
        if (rc != 0)
        {
            nv_printf(NV_DBG_ERRORS,
                      "NVRM: Failed to read PCI extended capability header at offset 0x%x while searching for NVIDIA DVSEC%u, rc 0x%x\n",
                      cap_offset, target_dvsec_id, rc);
            return NV_ERR_INVALID_READ;
        }

        if (NV_PCI_EXT_CAP_ID(hdr0) == NV_PCI_EXT_CAP_ID_DVSEC)
        {
            rc = pci_read_config_dword(dev,
                                       (cap_offset + NV_PCI_DVSEC_HEADER_1_OFFSET),
                                       &hdr1);
            if (rc != 0)
            {
                nv_printf(NV_DBG_ERRORS,
                          "NVRM: Failed to read DVSEC header 1 at offset 0x%x while searching for NVIDIA DVSEC%u, rc 0x%x\n",
                          cap_offset, target_dvsec_id, rc);
                return NV_ERR_INVALID_READ;
            }

            rc = pci_read_config_dword(dev,
                                       (cap_offset + NV_PCI_DVSEC_HEADER_2_OFFSET),
                                       &hdr2);
            if (rc != 0)
            {
                nv_printf(NV_DBG_ERRORS,
                          "NVRM: Failed to read DVSEC header 2 at offset 0x%x while searching for NVIDIA DVSEC%u, rc 0x%x\n",
                          cap_offset, target_dvsec_id, rc);
                return NV_ERR_INVALID_READ;
            }

            if ((NV_PCI_DVSEC_VENDOR_ID(hdr1) == NV_PCI_DVSEC_NVIDIA_VENDOR_ID) &&
                (NV_PCI_DVSEC_DESIGNATED_ID(hdr2) == target_dvsec_id))
            {
                *dvsec_offset = cap_offset;
                *dvsec_length = NV_PCI_DVSEC_LEN(hdr1);
                return NV_OK;
            }
        }

        cap_offset = NV_PCI_EXT_CAP_NEXT_OFFSET(hdr0);
        if (cap_offset == 0)
        {
            nv_printf(NV_DBG_INFO, "NVRM: Failed to find NVIDIA DVSEC%u\n",
                      target_dvsec_id);
            return NV_ERR_NOT_SUPPORTED;
        }
    }

    /*
     * If we reach here, the loop maximum number of iterations was reached,
     * which likely indicates a malformed/cyclic PCI extended capability chain.
     */
    nv_printf(NV_DBG_ERRORS,
              "NVRM: Malformed PCI extended capability chain while searching for NVIDIA DVSEC%u: traversal limit reached\n",
              target_dvsec_id);
    return NV_ERR_CYCLE_DETECTED;
}

NV_STATUS NV_API_CALL
nv_pci_read_gpu_pdi_from_dvsec
(
    nv_state_t *nv,
    NvU64 *pdi
)
{
    NV_STATUS status;
    struct pci_dev *pdev;
    NvU32 dvsec_offset;
    NvU32 dvsec_length;
    u32 pdi_low;
    u32 pdi_high;
    u64 pdi_value;
    int rc;

    if ((nv == NULL) || (pdi == NULL))
    {
        return NV_ERR_INVALID_ARGUMENT;
    }

    pdev = (struct pci_dev *)nv->handle;
    if (pdev == NULL)
    {
        return NV_ERR_INVALID_ARGUMENT;
    }

    status = nv_pci_find_nvidia_dvsec_capability(pdev,
                                                 NV_PCI_DVSEC_GPU_PDI_DESIGNATED_ID,
                                                 &dvsec_offset,
                                                 &dvsec_length);
    if (status != NV_OK)
    {
        return status;
    }

    /* Verify the DVSEC length. */
    if (dvsec_length < NV_PCI_DVSEC_GPU_PDI_CAP_LEN)
    {
        nv_printf(NV_DBG_ERRORS,
                  "NVRM: NVIDIA DVSEC3 PDI capability length 0x%x is smaller than expected 0x%x\n",
                  dvsec_length, NV_PCI_DVSEC_GPU_PDI_CAP_LEN);
        return NV_ERR_INVALID_DATA;
    }

    /* Verify that the DVSEC offset is within the extended capability space. */
    if (dvsec_offset > (NV_PCI_EXT_CAP_END_OFFSET - NV_PCI_DVSEC_GPU_PDI_CAP_LEN))
    {
        nv_printf(NV_DBG_ERRORS,
                  "NVRM: NVIDIA DVSEC3 PDI capability offset 0x%x cannot contain expected length 0x%x\n",
                  dvsec_offset, NV_PCI_DVSEC_GPU_PDI_CAP_LEN);
        return NV_ERR_INVALID_OFFSET;
    }

    rc = pci_read_config_dword(pdev,
                               (dvsec_offset + NV_PCI_DVSEC_GPU_PDI_LOW_OFFSET),
                               &pdi_low);
    if (rc != 0)
    {
        nv_printf(NV_DBG_ERRORS,
                  "NVRM: Failed to read PDI low DWORD from NVIDIA DVSEC3 at offset 0x%x, rc 0x%x\n",
                  dvsec_offset, rc);
        return NV_ERR_INVALID_READ;
    }

    rc = pci_read_config_dword(pdev,
                               (dvsec_offset + NV_PCI_DVSEC_GPU_PDI_HIGH_OFFSET),
                               &pdi_high);
    if (rc != 0)
    {
        nv_printf(NV_DBG_ERRORS,
                  "NVRM: Failed to read PDI high DWORD from NVIDIA DVSEC3 at offset 0x%x, rc 0x%x\n",
                  dvsec_offset, rc);
        return NV_ERR_INVALID_READ;
    }

    pdi_value = (((u64)pdi_high) << 32) | (u64)pdi_low;

    /* Validate the PDI. */
    if ((pdi_value == 0) || (pdi_value == NV_U64_MAX))
    {
        nv_printf(NV_DBG_ERRORS,
                  "NVRM: Invalid PDI value 0x%llx found in NVIDIA DVSEC3\n",
                  pdi_value);
        return NV_ERR_NOT_SUPPORTED;
    }

    *pdi = pdi_value;
    return NV_OK;
}

static void check_for_bound_driver(struct pci_dev *pci_dev)
{
    if (pci_dev->dev.driver)
    {
        const char *driver_name = pci_dev->dev.driver->name;

        nv_printf(NV_DBG_WARNINGS, "NVRM: GPU %04x:%02x:%02x.%x is already "
            "bound to %s.\n",
            NV_PCI_DOMAIN_NUMBER(pci_dev), NV_PCI_BUS_NUMBER(pci_dev),
            NV_PCI_SLOT_NUMBER(pci_dev), PCI_FUNC(pci_dev->devfn),
            driver_name ? driver_name : "another driver"
        );
    }
}

void NV_API_CALL nv_pci_cxl_set_caching(nv_state_t *nv, NvBool cache_enable)
{
    return;
}

/* make sure the pci_driver called probe for all of our devices.
 * we've seen cases where rivafb claims the device first and our driver
 * doesn't get called.
 */
int
nv_pci_count_devices(void)
{
    struct pci_dev *pci_dev;
    int count = 0;

    if (NVreg_RegisterPCIDriver == 0)
    {
        return 0;
    }

    pci_dev = pci_get_class(PCI_CLASS_DISPLAY_VGA << 8, NULL);
    while (pci_dev)
    {
        if (rm_is_supported_pci_device(
                PCI_BASE_CLASS_DISPLAY,
                PCI_CLASS_DISPLAY_VGA & 0xFF,
                pci_dev->vendor,
                pci_dev->device,
                pci_dev->subsystem_vendor,
                pci_dev->subsystem_device,
                NV_TRUE /* print_legacy_warning */))
        {
            check_for_bound_driver(pci_dev);
            count++;
        }
        pci_dev = pci_get_class(PCI_CLASS_DISPLAY_VGA << 8, pci_dev);
    }

    pci_dev = pci_get_class(PCI_CLASS_DISPLAY_3D << 8, NULL);
    while (pci_dev)
    {
        if (rm_is_supported_pci_device(
                (pci_dev->class >> 16) & 0xFF,
                (pci_dev->class >> 8) & 0xFF,
                pci_dev->vendor,
                pci_dev->device,
                pci_dev->subsystem_vendor,
                pci_dev->subsystem_device,
                NV_TRUE /* print_legacy_warning */))
        {
            check_for_bound_driver(pci_dev);
            count++;
        }
        pci_dev = pci_get_class(PCI_CLASS_DISPLAY_3D << 8, pci_dev);
    }

    return count;
}

/*
 * On coherent platforms that support BAR1 mappings for GPUDirect RDMA,
 * dma-buf and nv-p2p subsystems need to ensure the 2 devices belong to
 * the same IOMMU group. If the importer device doesn't have an IOMMU
 * group assigned, at least check if the GPU and importer are under the same
 * root port.
 */
NvBool nv_pci_is_valid_topology_for_direct_pci(
    nv_state_t     *nv,
    struct pci_dev *peer
)
{
    struct pci_dev *pdev0 = to_pci_dev(nv->dma_dev->dev);
    struct pci_dev *pdev1 = peer;

    if (!nv->coherent)
    {
        return NV_FALSE;
    }

    if (pdev0->dev.iommu_group == pdev1->dev.iommu_group)
        return NV_TRUE;

    if (pdev1->dev.iommu_group == NULL)
        return nv_pci_has_common_pci_switch(nv, peer);

    return NV_FALSE;
}

NvBool nv_pci_has_common_pci_switch(
    nv_state_t     *nv,
    struct pci_dev *peer
)
{
    struct pci_dev *pci_dev0, *pci_dev1;

    pci_dev0 = pci_upstream_bridge(to_pci_dev(nv->dma_dev->dev));

    while (pci_dev0 != NULL)
    {
        pci_dev1 = pci_upstream_bridge(peer);

        while (pci_dev1 != NULL)
        {
            if (pci_dev0 == pci_dev1)
                return NV_TRUE;

            pci_dev1 = pci_upstream_bridge(pci_dev1);
        }

        pci_dev0 = pci_upstream_bridge(pci_dev0);
    }

    return NV_FALSE;
}

NvBool NV_API_CALL nv_grdma_pci_topology_supported(
    nv_state_t      *nv,
    nv_dma_device_t *dma_peer
)
{
    //
    // Skip topo check on coherent platforms since
    // NIC can map over C2C anyway and PCIe topology shouldn't matter.
    //
    if (nv->coherent)
    {
        return NV_TRUE;
    }

    //
    // Allow RDMA by default on passthrough VMs and vGPU guests.
    // Guest RM sees the virtual chipset, not the host, so the P2P table
    // is not a valid topology signal.
    //
    if ((nv->flags & (NV_FLAG_PASSTHRU | NV_FLAG_VGPU_GUEST)) != 0)
        return NV_TRUE;

    //
    // Only allow RDMA on unsupported chipsets if there exists
    // a common PCI switch between the GPU and the other device
    //
    if ((nv->flags & NV_FLAG_PCI_P2P_UNSUPPORTED_CHIPSET) != 0)
        return nv_pci_has_common_pci_switch(nv, to_pci_dev(dma_peer->dev));

    return NV_TRUE;
}

static NvBool
nv_pci_read_tdisp_tdi_state
(
    struct pci_dev *pci_dev,
    NvU32          *dvsec0,
    NvU32          *tdi_state
)
{
    int ret;

    *dvsec0 = 0xffffffffU;
    *tdi_state = 0U;

    ret = pci_read_config_dword(
        pci_dev,
        NV_TDISP_AER_DVSEC0_OFFSET,
        dvsec0);

    if ((ret != PCIBIOS_SUCCESSFUL) || (*dvsec0 == 0xffffffffU))
        return NV_FALSE;

    *tdi_state = NV_TDISP_AER_TDI_STATE(*dvsec0);
    return NV_TRUE;
}

static void
nv_pci_report_error
(
    struct pci_dev *pci_dev,
    NvU32           xid,
    const char     *format,
    ...
)
{
    va_list ap;

    va_start(ap, format);
    nv_report_error(pci_dev, xid, format, ap);
    va_end(ap);
}

static void
nv_pci_report_tdisp_error
(
    struct pci_dev  *pci_dev,
    nv_linux_state_t *nvl
)
{
    nv_state_t *nv = NV_STATE_PTR(nvl);
    NvU32 dvsec0;
    NvU32 tdi_state;

    if (!nv_pci_read_tdisp_tdi_state(pci_dev, &dvsec0, &tdi_state))
    {
        NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                      "TDISP state unavailable during PCIe DPC containment\n");
        return;
    }

    if (tdi_state != NV_TDISP_AER_TDI_STATE_ERROR)
    {
        NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                      "PCIe DPC containment with TDI state=%u, DVSEC0=0x%08x\n",
                      tdi_state, dvsec0);
        return;
    }

    NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                  "TDISP ERROR during PCIe DPC containment: DVSEC0=0x%08x\n",
                  dvsec0);
    nv_pci_report_error(pci_dev,
                        NV_TDISP_AER_XID,
                        "TDISP ERROR detected during PCIe DPC containment, "
                        "DVSEC0=0x%08x, TDI_STATE=ERROR",
                        dvsec0);
}

static pci_ers_result_t
nv_pci_error_detected
(
    struct pci_dev         *pci_dev,
    nv_pci_channel_state_t  state
)
{
    //
    // Called under device_lock from the PCI error-recovery path. .remove and
    // .shutdown take the same lock, so once pci_get_drvdata returns a matching
    // nvl, that nvl and its embedded nv_state_t remain valid for this callback.
    //
    nv_linux_state_t *nvl = pci_get_drvdata(pci_dev);
    nv_state_t *nv;

    if ((nvl == NULL) || (nvl->pci_dev != pci_dev))
        return PCI_ERS_RESULT_DISCONNECT;

    nv = NV_STATE_PTR(nvl);

    if (state == pci_channel_io_normal)
    {
        NV_DEV_PRINTF(NV_DBG_INFO, nv,
                      "Nonfatal PCIe error detected; continuing recovery\n");
        return PCI_ERS_RESULT_CAN_RECOVER;
    }

    //
    // The GPU is off the bus. Fence RM API entry before anything else can
    // touch the device; see NV_IS_DEVICE_INACCESSIBLE().
    //
    // The flag is set so when GPU is unfrozen we still want to prevent accesses
    //
    nv->flags |= NV_FLAG_IN_PCIE_ERROR_RECOVERY;

    /*
     * Review-only PoC: DPC may already have made endpoint configuration
     * space inaccessible. Attempt exactly one DVSEC0 read and fail closed
     * when it fails or returns all ones. Never access BAR0, submit DMA, or
     * call osHandleGpuLost() from this callback.
     */
    if ((state == pci_channel_io_frozen) && os_tdisp_enabled &&
        (atomic_cmpxchg(&nvl->tdisp_aer_reported, 0, 1) == 0))
    {
        nv_pci_report_tdisp_error(pci_dev, nvl);
    }

    if (state == pci_channel_io_frozen)
    {
        NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                      "Fatal PCIe error detected; GPU marked inaccessible\n");
        //
        // NEED_RESET rather than DISCONNECT: pcie_do_recovery() broadcasts
        // slot_reset only when the merged status is exactly NEED_RESET.
        //
        return PCI_ERS_RESULT_NEED_RESET;
    }

    if (state == pci_channel_io_perm_failure)
    {
        //
        // Also reached as a consequence of our own DISCONNECT vote from
        // slot_reset: the kernel's recovery failure path re-enters
        // error_detected with a permanent failure state.
        //
        NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                      "PCIe link reported as permanently failed; GPU remains inaccessible\n");
    }
    else
    {
        NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                      "Unrecognized PCIe channel state %u; treating as fatal and marking GPU inaccessible\n",
                      (unsigned)state);
    }

    return PCI_ERS_RESULT_DISCONNECT;
}

static pci_ers_result_t
nv_pci_slot_reset
(
    struct pci_dev *pci_dev
)
{
    nv_linux_state_t *nvl;
    nv_state_t *nv;
    u32 id;
    u32 expected_id;

    /*
     * Kernels without commit 45bc82563d55 ("PCI/ERR: Update device error_state
     * already after reset", v6.18) restore error_state only from report_resume,
     * which our DISCONNECT vote skips. Perform the frozen -> normal transition
     * here so the device does not read as pci_channel_offline() forever.
     * cmpxchg both matches how the PCI core owns this field and can never
     * clobber pci_channel_io_perm_failure, and it is a harmless no-op where the
     * core has already done the transition.
     */
    cmpxchg(&pci_dev->error_state, pci_channel_io_frozen,
            pci_channel_io_normal);

    //
    // Called under device_lock from the PCI error-recovery path. .remove and
    // .shutdown take the same lock, so once pci_get_drvdata returns a matching
    // nvl, that nvl and its embedded nv_state_t remain valid for this callback.
    //
    nvl = pci_get_drvdata(pci_dev);
    if ((nvl == NULL) || (nvl->pci_dev != pci_dev))
        return PCI_ERS_RESULT_DISCONNECT;

    nv = NV_STATE_PTR(nvl);

    expected_id = (u32)pci_dev->vendor | ((u32)pci_dev->device << 16);
    if (pci_bus_read_config_dword(pci_dev->bus, pci_dev->devfn,
                                  PCI_VENDOR_ID, &id) != 0)
    {
        NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                      "PCI identity validation failed after slot reset (config read failed, expected=0x%08x)\n",
                      expected_id);
        return PCI_ERS_RESULT_DISCONNECT;
    }

    if (id != expected_id)
    {
        NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                      "PCI identity validation failed after slot reset (id=0x%08x, expected=0x%08x)\n",
                      id, expected_id);
        return PCI_ERS_RESULT_DISCONNECT;
    }

    /*
     * The link reset left the function at post-reset defaults, and neither the
     * kernel's recovery path nor a later rebind reprograms the BARs, so restore
     * the snapshot taken during probe. Bus mastering stays off so the lost GPU
     * cannot DMA, and the state is resaved that way so a subsequent
     * pci_reset_function() does not bring it back.
     */
    pci_restore_state(pci_dev);
    pci_clear_master(pci_dev);

    if (pci_save_state(pci_dev) != 0)
    {
        NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                      "Failed to resave PCI config state after slot reset\n");
    }

    NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                  "PCIe link reset after DPC/AER containment. The GPU is no longer usable and requires a reset before it will accept new work.\n");

    //
    // DISCONNECT so Linux never resumes this RM instance. Recovery is an
    // operator-driven unbind, sysfs reset and rebind.
    //
    return PCI_ERS_RESULT_DISCONNECT;
}

static const struct pci_error_handlers nv_pci_error_handlers = {
    .error_detected = nv_pci_error_detected,
    .slot_reset     = nv_pci_slot_reset,
};

#if defined(CONFIG_PM)
extern struct dev_pm_ops nv_pm_ops;
#endif

struct pci_driver nv_pci_driver = {
    .name      = MODULE_NAME,
    .id_table  = nv_pci_table,
    .probe     = nv_pci_probe,
    .remove    = nv_pci_remove,
    .shutdown  = nv_pci_shutdown,
#if defined(NV_USE_VFIO_PCI_CORE) && \
  defined(NV_PCI_DRIVER_HAS_DRIVER_MANAGED_DMA)
    .driver_managed_dma = NV_TRUE,
#endif
#if defined(CONFIG_PM)
    .driver.pm = &nv_pm_ops,
#endif
#if NV_PCI_ASYNC_PROBE_SUPPORTED
    .driver.probe_type = PROBE_PREFER_ASYNCHRONOUS,
#else
    .driver.probe_type = PROBE_FORCE_SYNCHRONOUS,
#endif
};

void nv_pci_wait_for_probe_complete(void)
{
    if (NVreg_RegisterPCIDriver == 0)
    {
        return;
    }

#if NV_PCI_ASYNC_PROBE_SUPPORTED
    /*
     * With PROBE_PREFER_ASYNCHRONOUS, pci_register_driver() may return
     * before all probes complete. Wait for all pending probes to finish
     * so that num_probed_nv_devices and num_nv_devices are final before
     * post-registration validation in nvidia_init_module().
     *
     * wait_for_device_probe() is system-wide (not NVIDIA-specific) but
     * is the standard kernel API for this purpose.
     */
    wait_for_device_probe();
#endif
}

void nv_pci_unregister_driver(void)
{
    if (NVreg_RegisterPCIDriver == 0)
    {
        return;
    }
    return pci_unregister_driver(&nv_pci_driver);
}

int nv_pci_register_driver(void)
{
    int rc;

    if (NVreg_RegisterPCIDriver == 0)
    {
        return 0;
    }

    //
    // Attach the error handlers here rather than statically, so that with the
    // feature disabled the kernel sees a handler-less driver and behaves exactly
    // as it did before these callbacks existed.
    //
    if (NVreg_EnablePCIeErrorRecovery != 0)
    {
        nv_pci_driver.err_handler = &nv_pci_error_handlers;
    }

    smp_store_release(&nv_pci_driver_registration_in_progress, NV_TRUE);

    rc = pci_register_driver(&nv_pci_driver);

    if (rc == 0)
    {
        nv_pci_wait_for_probe_complete();
    }

    smp_store_release(&nv_pci_driver_registration_in_progress, NV_FALSE);

    return rc;
}
